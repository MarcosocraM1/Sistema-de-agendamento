package br.edu.ifpb.listadinamicataiviny;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentManager;

import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.AdapterView;
import android.widget.Toast;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;
import java.util.List;

public class ListaActivity extends AppCompatActivity implements CadastroCategoriaAlertDialog.Cadastrolistener {

    private ListView lvCategorias;
    private FloatingActionButton fabAddCategoria;
    private List<String> listaCategorias;
    private ArrayAdapter<String> listaCategoriasAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lista);

        lvCategorias = findViewById(R.id.lvCategorias);
        fabAddCategoria = findViewById(R.id.fabAddCategoria);

        listaCategorias = new ArrayList<String>();

        listaCategoriasAdapter = new ArrayAdapter<String>(this,
                android.R.layout.simple_list_item_1,
                listaCategorias);

        lvCategorias.setAdapter(listaCategoriasAdapter);

        // Adiciona um contexto de clique longo para remover um item
        lvCategorias.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> parent, View view, int position, long id) {
                String categoriaRemovida = listaCategorias.get(position);
                listaCategorias.remove(position);
                listaCategoriasAdapter.notifyDataSetChanged();
                Toast.makeText(ListaActivity.this, "Categoria removida: " + categoriaRemovida, Toast.LENGTH_SHORT).show();
                return true;
            }
        });

        fabAddCategoria.setOnClickListener(new fabAddCategoriaOnClickListener());
    }

    @Override
    public void cadastrarCategoria(String categoria) {
        listaCategorias.add(categoria);
        listaCategoriasAdapter.notifyDataSetChanged();
    }

    private class fabAddCategoriaOnClickListener implements View.OnClickListener {
        @Override
        public void onClick(View view) {
            CadastroCategoriaAlertDialog cadastroCategoriaAlertDialog = new CadastroCategoriaAlertDialog();
            FragmentManager fragmentManager = getSupportFragmentManager();
            cadastroCategoriaAlertDialog.show(fragmentManager, "cadastro_categoria");
        }
    }
}
